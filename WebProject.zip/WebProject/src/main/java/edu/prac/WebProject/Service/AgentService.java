package edu.prac.WebProject.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.prac.WebProject.DAO.HotelDAO;
import edu.prac.WebProject.Model.Room;

@Service("userService1")
public class AgentService {

	@Autowired
	HotelDAO hotelDAO;

	public List<Room> accessAllUsers() {
		return hotelDAO.accessAllUsers();
	}

	public List<Room> filterByName(String name) {
		return hotelDAO.filterByName(name);
	}

	public int addUser(Room userModel) {
		return hotelDAO.addUser(userModel);
	}

	public int updateUser(Room userModel) {
		return hotelDAO.updateUser(userModel);
	}

	public int deleteUser(int id) {
		return hotelDAO.deleteUser(id);
	}
}
