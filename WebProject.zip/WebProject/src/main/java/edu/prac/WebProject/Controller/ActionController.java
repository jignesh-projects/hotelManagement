package edu.prac.WebProject.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import edu.prac.WebProject.Model.Room;
import edu.prac.WebProject.Service.AgentService;



@RestController
@RequestMapping("/hotel")
public class ActionController {

	@Autowired
	public AgentService agentService;
	
	@RequestMapping(value = "/addRoom", method = RequestMethod.POST)
	public ResponseEntity<String> addUser(@RequestBody String data, HttpServletRequest request,
			HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException {

		int i = 0;
		
		ObjectMapper mapper = new ObjectMapper();
		Room room = new Room();
		ObjectNode objectNode = mapper.readValue(data, ObjectNode.class);
		room = mapper.readValue(objectNode.toString(), Room.class);		
		i = agentService.addUser(room);
		if (i != 0) {
			return new ResponseEntity<String>("" + i, HttpStatus.OK);
		}
		return new ResponseEntity<String>("" + i, HttpStatus.CONFLICT);
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public List<Room> display() {
		List<Room> userList = agentService.accessAllUsers();
		return userList;
	}

	@RequestMapping(value = "filter/{key}", method = RequestMethod.GET)
	public List<Room> filter(@PathVariable("key") String key) {
		List<Room> userList = agentService.filterByName((String)key.trim());
		//return new ResponseEntity<>(userList, HttpStatus.OK);
		return userList;
	}

	@DeleteMapping(value = "delete/{id}")
	public int delete(@PathVariable("id") int id) {
		return agentService.deleteUser(id);
		
	}
	
	@RequestMapping(value = "/updateRoom", method = RequestMethod.POST)
	public ResponseEntity<String> updateUser(@RequestBody String data, HttpServletRequest request,
			HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException {

		int i = 0;
		
		ObjectMapper mapper = new ObjectMapper();
		Room room = new Room();
		ObjectNode objectNode = mapper.readValue(data, ObjectNode.class);
		room = mapper.readValue(objectNode.toString(), Room.class);		
		i = agentService.updateUser(room);
		if (i != 0) {
			return new ResponseEntity<String>("" + i, HttpStatus.OK);
		}
		return new ResponseEntity<String>("" + i, HttpStatus.CONFLICT);
	}
	
}
