package edu.prac.WebProject.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import edu.prac.WebProject.Model.Room;
import edu.prac.WebProject.util.GenericAccessor;



@Repository("userDAO1")
public class HotelDAO {

	@Autowired
	GenericAccessor genericAccessor;

	// Query Section
	private final static String fetchAll = "select * from hotel";
	private final static String updateQuery = "update hotel set name=?, description=?, availablity=? where id=?";
	private final static String deleteQuery = "delete from hotel where id=?";
	private static String fetchByName = "select * from hotel" + " WHERE name like '%param%'";
//	+ " OR id like '%param%'"
//	+ " OR description like '%param%'" + " OR availablity like '%param%'";
	private final static String insertQuery = "insert into hotel(id, name , description, availablity) values(?,?,?,?)";

	// Declaration
	List<Room> room = null;

	// Implementation
	public List<Room> accessAllUsers() {
		List<Room> room = genericAccessor.getJdbcTemplate().query(fetchAll,
				new BeanPropertyRowMapper(Room.class));

		return room;
	}

	public List<Room> filterByName(String name) {
		String query = fetchByName.replaceAll("param", name);
		List<Room> room = genericAccessor.getJdbcTemplate().query(query, new UserMapper());

		return room;
	}

	public int addUser(Room room) {
		int i = genericAccessor.getJdbcTemplate().update(insertQuery,
				new Object[] { room.getId(), room.getName(), room.getDescription(), room.getAvailablity() });
		return i;
	}
	
	public int updateUser(Room room) {
		int i = genericAccessor.getJdbcTemplate().update(updateQuery,
				new Object[] { room.getName(), room.getDescription(), room.getAvailablity(), room.getId() });
		return ++i;
	}
	
	public int deleteUser(int id) {
		int i = genericAccessor.getJdbcTemplate().update(deleteQuery,
				new Object[] {id});
		return i;
	}

	// RowMapper
	private static final class UserMapper implements RowMapper<Room> {
		@Override
		public Room mapRow(ResultSet rs, int rowNum) throws SQLException {
			Room Room = new Room();
			Room.setId(rs.getInt(1));
			Room.setName(rs.getString(2));
			Room.setDescription(rs.getString(3));
			Room.setAvailablity(rs.getInt(4));

			return Room;
		}
	}

}
